/* Generated file based on ejs templates */
define([], function() {
    return {
    "Python.py.ejs": "print \"<%=a%> and <%=b%> provided.\""
}});